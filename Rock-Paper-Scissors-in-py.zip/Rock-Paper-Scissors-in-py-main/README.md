# Rock-Paper-Scissors-in-py
To run this python program, the user must pick either (r,p,s) as your input and then the computer (the second player) chooses its input on random
If both choice are the same, it print "it was a draw" 
if the user input is diffrent from the computer it print the winner
